package com.cg.bean;

public class BankBean {

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	

	public BankBean(String name, long accNo, int pin, String add, String phone, String email, int balance,
			String trans) {
		super();
		this.name = name;
		this.accNo = accNo;
		this.pin = pin;
		this.add = add;
		this.phone = phone;
		this.email = email;
		this.balance = balance;
		this.trans = trans;
	}

	public BankBean() {
		// TODO Auto-generated constructor stub
	}

	private String name;
	private long accNo;
	private int pin;
	private String add;
	private String phone;
	private String email;
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	private int balance;

	String trans = new String();

	public String getTrans() {
		return trans;
	}

	public void setTrans(String string) {
		trans = string;
	}

	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getPhone() {
		return phone;
	}

	
	@Override
	public String toString() {
		return "BankBean [name=" + name + ", accNo=" + accNo + ", pin=" + pin + ", add=" + add + ", phone=" + phone
				+ ", email=" + email + ", balance=" + balance + ", trans=" + trans + "]";
	}


	

	public void setPhone(String phone2) {
		this.phone = phone2;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccNo() {
		return accNo;
	}

	public long setAccNo(long accNo2) {
		return this.accNo = accNo2;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

}
